<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $indexToDelete = $_POST['index'];

  $data = json_decode(file_get_contents('data.json'), true);

  if (isset($data[$indexToDelete])) {
    unset($data[$indexToDelete]);

    $data = array_values($data);

    foreach ($data as $index => &$item) {
      $item['№'] = $index + 1;
    }

    file_put_contents('data.json', json_encode($data));
  }

  header("Location: read.php");
  exit();
}

$data = json_decode(file_get_contents('data.json'), true);
$recordIndexes = array_keys($data);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="data.css" rel="stylesheet">
  <style>
    body{
      display: flex;
      flex-direction: column;  
      background-color: rgb(150,75,100)
    }
    h1{
      margin: 0 auto;
    }
    a{
      align-self: start;
    }
  </style>
</head>
<body class="container mt-5">
  <h1>Удалить данные</h1>
  <form method="post" action="">
    <div class="mb-3">
      <label for="index" class="form-label">Выберите индекс записи для удаления</label>
      <select class="form-select" id="index" name="index" required>
        <?php foreach ($recordIndexes as $recordIndex): ?>
          <option value="<?= $recordIndex ?>"><?= $recordIndex + 1 ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <button type="submit" class="btn btn-danger">
      Удалить запись <span class="badge">✘</span>
    </button>
  </form>
  <a class="btn btn-secondary mt-3" href="index.html">
    На главную <span class="badge">←</span>
  </a>
</body>
</html>