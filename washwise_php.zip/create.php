<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_decode(file_get_contents('data.json'), true);

  $newNumber = count($data) + 1;

  $newRecord = [
    '№' => $newNumber,
    'Модель' => $_POST['model'],
    'Загрузка (кг)' => $_POST['capacity'],
    'Скорость отжима (об/мин)' => $_POST['spinspeed'],
    'Класс энергопотребления' => $_POST['energy'],
    'Цена (в рублях)' => $_POST['price']
  ];

  $data[] = $newRecord;

  file_put_contents('data.json', json_encode($data));

  header("Location: read.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="data.css" rel="stylesheet">
  <style>
    body{
      display: flex;
      flex-direction: column; 
  background-color: rgb(100,100,100)
    }
    h1{
      margin: 0 auto;
    }
    a{
      align-self: start;
    }
  </style>
</head>
<body class="container mt-5">
        <h1>Добавить запись</h1>
        <form method="post" action="">
          <div class="mb-3">
            <label for="model" class="form-label">Введите название модели</label>
            <input type="text" class="form-control" id="model" name="model" required>
          </div>
          <div class="mb-3">
            <label for="capacity" class="form-label">Выберите загрузку</label>
            <select class="form-select" id="capacity" name="capacity" required>
              <option value="4">4 кг</option>
              <option value="5">5 кг</option>
              <option value="6">6 кг</option>
              <option value="7">7 кг</option>
              <option value="8">8 кг</option>
              <option value="9">9 кг</option>
              <option value="10">10 кг</option>
              <option value="11">11 кг</option>
              <option value="12">12 кг</option>
      </select>
    </div>
    <div class="mb-3">
        <label for="spinspeed" class="form-label">Выберите скорость отжима</label>
        <select class="form-select" id="spinspeed" name="spinspeed" required>
          <option value="1200+">от 1200 об/мин</option>
          <option value="1100-1200">1100-1200 об/мин</option>
          <option value="900-1100">900-1200 об/мин</option>
          <option value="800-900">800-900 об/мин</option>
          <option value="700-800">700-800 об/мин</option>
          <option value="700-">до 700 об/мин</option>
      </select>
    </div>
    <div class="mb-3">
      <label for="energy" class="form-label">Выберите класс энергопотребления</label>
      <select class="form-select" id="energy" name="energy" required>
          <option value="A+++">A+++</option>
          <option value="A++">A++</option>
          <option value="A+">A+</option>
          <option value="A">A</option>
          <option value="B">B</option>
      </select>
      </div>
      <div class="mb-3">
         <label for="price" class="form-label">Введите цену (в рублях)</label>
        <input type="text" class="form-control" id="price" name="price" required>
      </div>
      <button type="submit" class="btn btn-success">
        Добавить запись <span class="badge">+</span>
      </button>
  </form>
  <a class="btn btn-secondary mt-3" href="index.html">
    На главную <span class="badge">←</span>
  </a>
</body>
</html>