<?php
$data = json_decode(file_get_contents('data.json'), true);
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="data.css" rel="stylesheet">
  <style>
    body{
      display: flex;
      flex-direction: column;  
      background-color: rgb(100,100,100)
    }
    h1{
      margin: 0 auto;
    }
    a{
      align-self: start;
    }
    table{
      margin-top: 20px;
    }
  </style>
</head>
<body class="container mt-5">
  <h1>Читать данные</h1>
  <table class="table table-success table-striped-columns">
    <thead>
      <tr>
        <th>№</th>
        <th>Модель</th>
        <th>Загрузка (кг)</th>
        <th>Скорость отжима (об/мин)</th>
        <th>Класс энергопотребления</th>
        <th>Цена (в рублях)</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($data as $record): ?>
        <tr>
          <td><?= $record['№'] ?></td>
          <td><?= $record['Модель'] ?></td>
          <td><?= $record['Загрузка (кг)'] ?></td>
          <td><?= $record['Скорость отжима (об/мин)'] ?></td>
          <td><?= $record['Класс энергопотребления'] ?></td>
          <td><?= $record['Цена (в рублях)'] ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <a class="btn btn-secondary mt-3" href="index.html">
    На главную <span class="badge">←</span>
  </a>
</body>
</html>